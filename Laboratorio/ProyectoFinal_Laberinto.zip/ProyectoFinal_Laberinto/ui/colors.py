COLORS = {
    "bg": "#2C2C2C",
    "path": "#858585",
    "wall": "#09234B",
    "wall_outline": "#0B3068",
    "goal": "#35B55E",
    "player": "#FCFCFC",
    "player_outline": "black",
    "title": "#FFFFFF",
    "btn_bg": "#F71212",
    "btn_Resolver_bg": "#2DC485",
    "btn_Detener_bg": "#777676",
    "btn_active": "#D5D6D6"
}
